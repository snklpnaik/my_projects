<?php
require("config.php");
?>
<!doctype html>
<!-- Designed & Developed by Tech Vegan https://bit.ly/2MFT35Q 
		NOT FOR SELLING PURPOSE

        CAN USE FOR COLLEGE/SCHOOL PROJECT SUBMISSION
       
        For More Subscribe YouTube Channel "Tech Vegan" https://bit.ly/2MFT35Q
        
        DESIGNED WITH LOVE FOR ALL
-->
<html>
<head>
<meta charset="utf-8">
<title>Student Information Portal</title>
<link href="Sankalp.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="header" align="center">
<span class="heading">MANGALORE INSTITUTE TECHNOLOGY ENGINEERING, MANGALORE</span>
</div>
<br>
<br>

<div align="center">

<br>
<br>
<br>
<br>
<br>

<div id="content">
<br>

<span class="subHead">STUDENT INFORMATION REGISTRATION PANEL</span>
<br>
<br>
<hr />
<span class="Text">N O T I F I C A T I O N</span>
<hr />
<br>
<span class="flashTrue"> Thank you!! Registered Successfully </span>
<br>
<br>
<br>
<input type="button" value="New Registration" onClick="window.location='index.php'" />

<br>
<br>

</div>
<br>
<br>
<br>
<br>
<br>
<?php require("footer.php");?>
</body>
<!-- Designed & Developed by Tech Vegan https://bit.ly/2MFT35Q 
		NOT FOR SELLING PURPOSE

        CAN USE FOR COLLEGE/SCHOOL PROJECT SUBMISSION
       
        For More Subscribe YouTube Channel "Tech Vegan" https://bit.ly/2MFT35Q
        
        DESIGNED WITH LOVE FOR ALL
--> </html>

