<?php
error_reporting(0);
session_start();
$al = mysqli_connect("sankalpn46687.netfirmsmysql.com","root1","@Glowtouch12345","student_info");
date_default_timezone_set("Asia/Mumbai");
?>