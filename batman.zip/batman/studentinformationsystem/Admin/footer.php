<div id="footer">
For DBMS Project | By sAs | Designed &amp; Programmed By <a class="footerL">sAs</a> | <?php if(!isset($_SESSION['lid'])) 
{ ?> <a href="" class="footerL">Admin Login</a> <?php } else { ?><a href="home.php" class="footerL">Home</a> | <a href="logout.php" class="footerL">Logout</a><?php } ?> | <a href="../" class="footerL">Exit</a>
</div>