<?php  
// export.php  
 
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 
if (isset($_POST["export"])) {  
    // Database connection
    $connect = mysqli_connect("sankalpn46687.netfirmsmysql.com", "root1", "@Glowtouch12345", "student_info");
    
    // Check connection
    if (!$connect) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    // Set headers to download file
    header('Content-Type: text/csv; charset=utf-8');  
    header('Content-Disposition: attachment; filename=data.csv');  
    
    // Open output stream
    $output = fopen("php://output", "w");  
    
    // Output column headings
    fputcsv($output, array(
        'Roll No.', 'First Name', 'Middle Name', 'Last Name', 'Gender', 'DOB', 'Contact No.', 'Email', 'Adhaar No.',
        'Perm Address', 'Corr Address', 'Course', 'Branch', 'Acd Year', 'Purs Year', 'Section', 'Category', 'Caste', 
        'Sub-Caste', 'SSC Roll No.', 'SSC Marks', 'SSC Total Marks', 'SSC Percentage', 'SSC Board', 'HSSC Roll No.', 
        'HSSC Marks', 'HSSC Total Marks', 'HSSC Percentage', 'HSSC Board', 'GATE Roll No.', 'GATE Marks', 
        'GATE Total Marks', 'GATE Percentage', 'GATE Rank', 'KCET Marks', 'KCET Rank', 'JEE Marks', 'JEE Rank'
    ));  
    
    // Query to get data
    $query = "SELECT 
                roll_no, first_name, middle_name, last_name, gender, date_of_birth, contact_no, email, adhaar_no, 
                permanent_address, correspondence_address, course, branch, academic_year, year, section, category, 
                caste, sub_caste, ssc_roll, ssc_marks_obtained, ssc_total_marks, ssc_percentage, board_type_1, 
                hssc_roll, hssc_marks_obtained, hssc_total_marks, hssc_percentage, board_type_2, gate_roll, 
                gate_marks_obtained, gate_total_marks, gate_percentage, gate_rank, k_cet_marks, k_cet_rank, 
                jee_marks, jee_rank 
              FROM students 
              ORDER BY roll_no ASC";
    
    $result = mysqli_query($connect, $query);  
    
    // Check if query executed successfully
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {  
            fputcsv($output, $row);  
        }
    } else {
        echo "Error executing query: " . mysqli_error($connect);
    }
    
    // Close output stream
    fclose($output);  
    // Close database connection
    mysqli_close($connect);
}  
?>