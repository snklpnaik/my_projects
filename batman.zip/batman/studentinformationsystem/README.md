Student Information System mainly has an objective of storing the data of the student in the database. The project is used to maintain student details . The database has both student and the details about them. 

We use XAMPP Server application as the application for managing apache and mysql servers.
The application is developed with html, css, javascript and php.
The webpages are of .php files.



how to run:
open xampp application, start apache and mysql servers. Click the admin button in mysql and create a database or else create a database using sql queries, anyone is fine.
in C drive, open xamp folder, then hdocs, then copy you project here.
enter url as: localhost/folder_name_you_have_in_htdocs